<?php
session_start();

// Include the database connection file
include 'assets/database/accounts.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    // Fetch user details
    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ? AND status = 'active'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($role);
    $stmt->fetch();
    $stmt->close();

    // Redirect based on user role
    if ($role == 'vendor') {
        header("Location: vendor/dashboard.php");
    } elseif ($role == 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        // Handle unexpected role
        header("Location: account/login.php");
    }
    exit();
} else {
    // Redirect to login page if not logged in
    header("Location: account/login.php");
    exit();
}
?>
