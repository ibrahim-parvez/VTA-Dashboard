<?php
// Database configuration
$servername = "127.0.0.1";
$username = "iparvez_technical_alert";
$password = "techncialalert";
$dbname = "iparvez_technical_alert";
$port = 3306;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>